getStatistics();
function getStatistics() {
        try {
                print("Executing computation script for feature: airFiberStatistics");
				for (var i = 0; i < airFiberStatistics.size(); i++) {
				var stats = airFiberStatistics.get(i);
                output=getOutputTemplate();
				output.index=String(i);
				output.rxFrameCrcErr=stats.rxFrameCrcErr;
				output.rxAlignErr=stats.rxAlignErr;
				output.rxErroredFrames=stats.rxErroredFrames;
				output.rxDroppedMacErrFrames=stats.rxDroppedMacErrFrames;
				output.rxOverLengthFrames=stats.rxOverLengthFrames;
				output.rxTooLongFrameCrcErr=stats.rxTooLongFrameCrcErr;
				output.rxTooShortFrameCrcErr=stats.rxTooShortFrameCrcErr;
				output.txErroredFrames=stats.txErroredFrames;
				output.metricName="Errors";
				output.metricNamePK="Packets";
				output.txpktsAll=stats.txpktsAll;
				output.rxpktsAll=stats.rxpktsAll;
				scriptOutput.add(output);
				}
				print("Completed executing computation script for feature: getStatistics");
                return true;
            }
         catch (e) 
		{
			print("failed in getStatistics" + "  " + e.stack);
			return false;
		}
}
function getOutputTemplate () {
        var output = 
		{
			"rxFrameCrcErr":"value",
			"rxAlignErr":"value",
			"rxErroredFrames":"value",
			"txErroredFrames":"value",
			"rxDroppedMacErrFrames":"value",
			"rxOverLengthFrames":"value",
			"rxTooLongFrameCrcErr":"value",
			"rxTooShortFrameCrcErr":"value",
			"txpktsAll":"value",
			"rxpktsAll":"value",
			"componentId":"Errors",
			"index":0,
		};
                  return output;
}
