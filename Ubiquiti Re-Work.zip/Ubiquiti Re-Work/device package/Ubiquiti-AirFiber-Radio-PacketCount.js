getPacketCount();

function getPacketCount() {
	try {
		print("Executing computation script for feature: PacketCount");
		for (var i = 0; i < PacketCount.size(); i++) {
			var stats = PacketCount.get(i);

			/*This is for radio receive Packets Count*/
			output1 = getOutputTemplate();

			output1.index = "0";
			output1.metricName = "Packets";
			output1.label = "Receive Packets";

			output1.packetcount = stats.rxpktsAll;

			output1.type = "Receive";

			scriptOutput.add(output1);

			/*This is for radio Transmit Packets Count*/


			output2 = getOutputTemplate();

			output2.index = "1";
			output2.metricName = "Packets";

			output2.label = "Transmit Packets";

			output.packetcount = stats.txpktsAll;

			output2.type = "Transmit";

			scriptOutput.add(output2);


			print("Completed executing computation script for feature: PacketCount");

		}
		return true;
	} catch (e) {
		print("failed in Fan Status" + "  " + e.stack);
		return false;
	}
}


function getOutputTemplate() {
	var output = {};
	return output;
}