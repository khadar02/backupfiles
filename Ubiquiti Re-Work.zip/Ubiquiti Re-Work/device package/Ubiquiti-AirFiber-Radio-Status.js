getradioStatus();

function getradioStatus() {
	try {
		print("Executing computation script for feature: airFiberStatus");
		for (var i = 0; i < radioStatus.size(); i++) {
			var stats = radioStatus.get(i);
			output = getOutputTemplate();
			output.index = String(i);
			
			
			//radio link up time
			output.linkUpTime = stats.linkUpTime;
			

			output.metricNameLUT = "linkUpTime";

			//radio link state 1-> up 0-> down
			
			output.X=stats.radioLinkState;
			
			
			if (stats.radioLinkState == 1) {
				output.RadioLinkState = 100;
				output.linkStateStatusString = "UP";
			} else {
				output.RadioLinkState = 0;
				output.linkStateStatusString = "Down";
			}

			output.metricNameRLS = "radioLinkState";

			//radio link info 0->non operational 1-> operational
			if (stats.radioLinkInfo != "operational") {
				output.radioLinkInfo = 0;
				output.linkInfoString = "Down"
			} else {
				output.radioLinkInfo = 100;
				output.linkInfo = "UP";
			}
			output.metricNameRLI = "radioLinkInfo";

			
			output.radioName = "Antenna";

			scriptOutput.add(output);
		}
		print("Completed executing computation script for feature: getStatistics");
		return true;
	} catch (e) {
		print("failed in getStatus" + "  " + e.stack);
		return false;
	}
}

function getOutputTemplate() {
	var output = {

	};
	return output;
}