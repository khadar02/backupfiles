getradioTemp();
function getradioTemp() {
	try {
		print("Executing computation script for feature: Pan Status");
		for (var i = 0; i < radioTemp.size(); i++) {
			var stats = radioTemp.get(i);
			
			/*This is for radio1 temperature*/
			
			output1=getOutputTemplate();
			
			output1.metricName="ciscoEnvMonTemperatureState";
			output1.index="0";
			
			output1.componentId="Sensor";
			output1.label="Radio0";
			
			output1.temperatureCelsius=(stats.radio0TempC);
			
			scriptOutput.add(output1);

			/*This is for radio1 temperature*/
			
			output2=getOutputTemplate();
			
			output2.metricName="ciscoEnvMonTemperatureState";
			output2.index="1";
			
			output2.componentId="Sensor";
			output2.label="Radio1";
			
			output2.temperatureCelsius=(stats.radio1TempC);
			
			
			scriptOutput.add(output2);

			
			print("Completed executing computation script for feature: Fan Status");
			
		}
		return true;
	}
	catch (e) {
			print("failed in Fan Status" + "  " + e.stack);
			return false;
		}
}

function getOutputTemplate () {
	var output = {
	};
	return output;
}