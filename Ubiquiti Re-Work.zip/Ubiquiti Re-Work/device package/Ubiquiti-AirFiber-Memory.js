getMemory();
function getMemory() {
        try {
			    print("Executing computation script for feature: Memory");
			
				var stats = Memory.get(0);
                output=getOutputTemplate();
				output.ciscoMemoryPoolUsed=100-((stats.MemFree/stats.MemTotal)*100);
				output.ciscoCseSysMemoryUtilization=100-((stats.MemFree/stats.MemTotal)*100);
				output.ciscoMemoryPoolName="Memory";
				output.ciscoMemoryPoolType="Memory";
                scriptOutput.add(output);
				print("Completed executing computation script for feature: Memory")
                return true;
            }
         catch (e) {
                print("failed in Memory" + "  " + e.stack);
                return false;
        }
}
function getOutputTemplate () {
        var output = {
				
			};
        return output;
}
