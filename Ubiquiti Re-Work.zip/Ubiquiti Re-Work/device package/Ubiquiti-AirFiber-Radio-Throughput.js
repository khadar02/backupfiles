getThroughPutCapacity();
function getThroughPutCapacity() {
	try {
		print("Executing computation script for feature: Pan Status");
		for (var i = 0; i < ThroughPutCapacity.size(); i++) {
			var stats = ThroughPutCapacity.get(i);
			
			/*This is for radio receive through put capacity*/
			output1=getOutputTemplate();
			
			output1.index="0";
			output1.metricName="Capacity";
			output1.label="Receive";
			
			output1.rxCapacity = getRoundedToTwoDecimalPlaces(((stats.rxCapacity) / (1024 * 1024)));
						
			output1.metricValue=output1.rxCapacity;
			
			output1.type="Receive";
			
			scriptOutput.add(output1);

			/*This is for radio transmit throughput capacity*/
			
			
			output2=getOutputTemplate();
			
			output2.index="1";
			output2.metricName="Capacity";
			output2.label="Transmit";
			
			output2.txCapacity = getRoundedToTwoDecimalPlaces(((stats.txCapacity) / (1024 * 1024)));
						
			output2.metricValue=output2.txCapacity;
			
			output2.type="Transmit";
			
			scriptOutput.add(output2);

			
			print("Completed executing computation script for feature: Fan Status");
			
		}
		return true;
	}
	catch (e) {
			print("failed in Fan Status" + "  " + e.stack);
			return false;
		}
}

function getRoundedToTwoDecimalPlaces(doubleValue) {
	return (new java.lang.Double(java.lang.Math.round(doubleValue * 100))) / (100.0);
}


function getOutputTemplate () {
	var output = {
	};
	return output;
}