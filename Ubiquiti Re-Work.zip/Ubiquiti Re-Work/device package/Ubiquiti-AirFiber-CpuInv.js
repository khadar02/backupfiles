getCpuInv();

function getCpuInv() {
	try {
		print("Executing computation script for feature: CPUInventory");
		for (var i = 0; i < CPUInventory.size(); i++) {
			var stats = CPUInventory.get(i);
			if (stats.CPUMetricDescr == "5 Minute Average") {
				output = getOutputTemplate();
				output.utilization = stats.CPUMetricValue;
				output.name = "CPU";
				scriptOutput.add(output);
			}
		}
		print("Completed executing computation script for feature: CPUInventory");
		return true;
	} catch (e) {
		print("failed in CPUInventory" + "  " + e.stack);
		return false;
	}
}

function getOutputTemplate() {
	var output = {

	};
	return output;
}