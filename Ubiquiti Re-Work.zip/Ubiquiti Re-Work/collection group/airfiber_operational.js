function airfiber_operational(data) {
	data.point.addField("type", "Operational Status");
	return new java.lang.Double(data.radioLinkInfo);
}