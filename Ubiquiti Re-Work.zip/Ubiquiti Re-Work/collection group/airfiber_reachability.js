function airfiber_reachability(data) {
	data.point.addField("type", "Reachability");
	return new java.lang.Double(data.RadioLinkState);
}