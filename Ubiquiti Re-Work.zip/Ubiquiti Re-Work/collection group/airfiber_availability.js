function airfiber_availability(data) {

	data.point.addField("type", "Availability");
	if (data.linkUpTime == -1) {
		return new java.lang.Double(100.0);
	} else {
		return ((data.linkUpTime / data.pollFrequencySeconds) * 100 >= 100) ? new java.lang.Double(100.0):new java.lang.Double(0.0);
	}
return new java.lang.Double(data.linkUpTime);
}