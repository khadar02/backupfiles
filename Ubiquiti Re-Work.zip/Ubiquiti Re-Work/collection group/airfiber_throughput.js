function airfiber_throughput(data) {
	if (data.type == "Receive") {
		data.point.addField("type", "Receive");		
	}
	else 
	{
		data.point.addField("type", "Transmit");
	}
return new java.lang.Double(data.metricValue); 
}