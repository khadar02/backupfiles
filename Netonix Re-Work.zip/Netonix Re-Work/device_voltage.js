function device_voltage(data) {
data.point.addField("type", data.voltageSensorName);
return new java.lang.Double(data.Voltage); 
}