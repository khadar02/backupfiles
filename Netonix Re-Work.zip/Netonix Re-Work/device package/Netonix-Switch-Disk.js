getDiskTable();
function getDiskTable() {
	try {
		print("Executing computation script for feature: DiskTable");
		for (var i = 0; i < DiskTable.size(); i++) {
			var stats = DiskTable.get(i);
			output=getOutputTemplate();
			output.index=String(i);
			//output.dskIndex=stats.dskIndex;
			//output.dskPath=stats.dskPath;
			output.name="Disk";
			output.totalSpaceGB=stats.dskTotal; // change it to GB
			output.usedSpaceGB=stats.dskUsed;
			output.freeSpaceGB=stats.dskAvail;
			output.utilization=stats.dskPercent;
			//output.dskPercentNode=stats.dskPercentNode;
			scriptOutput.add(output);
			print("Completed executing computation script for feature: DiskTable");
		}
		return true;
	}
	catch (e) {
		print("failed in DiskTable" + "  " + e.stack);
		return false;
		}
}
function getOutputTemplate () {
	var output = {
		"metricName":"ciscoFlashPartitionUtilization",
		"componentId":"Disk-Partition"
	};
    return output;
}

