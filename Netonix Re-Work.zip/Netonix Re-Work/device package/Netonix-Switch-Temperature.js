gettempTable();
function gettempTable() {
	try {
		print("Executing computation script for feature: tempTable");
		for (var i = 0; i < tempTable.size(); i++) {
			var stats = tempTable.get(i);
			output=getOutputTemplate();
			output.index=String(i);
			output.tempIndex=stats.tempIndex;
			output.label="Temperature Sensor - "+i;
			output.temperatureCelsius=stats.temp;
			scriptOutput.add(output);
		    	
			print("Completed executing computation script for feature: tempTable");
		}
		return true;
	}
	catch (e) {
		print("failed in tempTable" + "  " + e.stack);
		return false;
		}
}

function getOutputTemplate () {
	var output = {
		"componentId":"Sensor",
		"metricName":"ciscoEnvMonTemperatureState"
	};
    return output;
}

