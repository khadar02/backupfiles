getCpu();
function getCpu() {
        try {
                print("Executing computation script for feature: CPU");
				// we need to implement the parse float thing here itself
				var stats = Cpu.get(0);
                output=getOutputTemplate();
				output.utilization=100-stats.ssCpuIdle;
				var a= parseFloat(output.utilization);
                scriptOutput.add(output);
				
				print("Completed executing computation script for feature: CPU");
                return true;
            }
         catch (e) {
                print("failed in CPU" + "  " + e.stack);
                return false;
        }
}
function getOutputTemplate () {
        var output = {
				"component":"CPU",
				"name":"CPU"
			};
        return output;
}
