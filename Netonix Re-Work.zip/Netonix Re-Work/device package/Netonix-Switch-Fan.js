getfanTable ();
function getfanTable() {
	try {
		print("Executing computation script for feature: fanTable");
		for (var i = 0; i < fanTable.size(); i++) {
			var stats = fanTable.get(i);
			
			output=getOutputTemplate();
			
			output.index=stats.fanIndex+"";
			
			output.fanSpeed=stats.fanSpeed;
			output.label="FAN ";
			
			if ("fanSpeed" in stats | stats.fanSpeed==null)
			{
				output.statusValue=0;
				output.statusString="Bad";
			}	
			else
			{
				output.statusValue=100;
				output.statusString="Good";
			}
			
			output.componentId="Fan";
			output.metricName="ciscoEnvMonFanState";
			scriptOutput.add(output);
			
			print("Completed executing computation script for feature: fanTable");
		}
		return true;
	}
	catch (e) {
		print("failed in fanTable" + "  " + e.stack);
		return false;
		}
}
function getOutputTemplate () {
	var output = {
	};
    return output;
}
