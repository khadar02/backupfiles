getIDTable();

function getIDTable() {

        try {
                print("Executing computation script for feature: IDTable");
				for (var i = 0; i < IDTable.size(); i++) {
				var stats = IDTable.get(i);
                output=getOutputTemplate();
				output.utilization=stats.fgIpsIntrusionsDetected;
                scriptOutput.add(output);
				}
				print("Completed executing computation script for feature: IDTable");
                return true;
            }
         catch (e) {
                print("failed in IDTable" + "  " + e.stack);
                return false;
        }
}

function getOutputTemplate () {
        var output = {
			"name":"fgIpsIntrusionsDetected",
			"utilization":0,
                        "component":"device-utm"
              
			};
			return output;
}
