getSessions();

function getSessions() {

        try {
                print("Executing computation script for feature: Sessions");

				var stats = Sessions.get(0);
                output=getOutputTemplate();
				output.utilization=stats.fgSysSesCount;
				scriptOutput.add(output);
				print("Completed executing computation script for feature: Sessions");
                return true;
            }
         catch (e) {
                print("failed in Sessions" + "  " + e.stack);
                return false;
        }
}

function getOutputTemplate () {
        var output = {
			"name":"SessionCountIPv4",
			"utilization":1
			};
                  return output;
}