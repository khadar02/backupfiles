getFlashDiskMetrics();

function getFlashDiskMetrics() {

    try {
        print("Executing computation script for feature: Flash");

        var stats1 = Disk_Flash.get(0);
        output1 = getOutputTemplate();
		output1.index="0";
		
        //1024*1024*1024=1073741824 Gb
        output1.flashfree = stats1.AvSysFlashFree;
        output1.freeSpaceGB = ((stats1.AvSysFlashFree) / 1073741824); //GB
        output1.usedSpaceGB = ((stats1.AvSysFlashUsage) / 1073741824); //GB
        output1.totalSpaceGB = (output1.freeSpaceGB + output1.usedSpaceGB);
		output1.name="Flash-Disk";
		
		
        if (output1.totalSpaceGB != 0) {
            output1.utilization = getRoundedToTwoDecimalPlaces(((output1.usedSpaceGB) / (output1.totalSpaceGB))*100);
        } else {
            output1.utilization = 0;
        }

        scriptOutput.add(output1);


        var stats2 = Disk_PCM.get(0);
        output2 = getOutputTemplate();
		output2.index="1";
		
        output2.freeSpaceGB = ((stats2.AvSysPCMFree) / 1073741824); 
        output2.usedSpaceGB = ((stats2.AvSysPCMUsed) / 1073741824); 
        output2.totalSpaceGB = (output2.freeSpaceGB + output2.usedSpaceGB);
		output2.name="PCMCIA-Disk";

        if (output2.totalSpaceGB != 0) {
            output2.utilization = getRoundedToTwoDecimalPlaces(((output2.usedSpaceGB) / (output2.totalSpaceGB)) * 100);
        } else {
            output2.utilization = 0;
        }


        scriptOutput.add(output2);


        var stats3 = Disk_NVME.get(0);
        output3 = getOutputTemplate();
		output3.index="2";
		
		//1024*1024
        output3.usedSpaceGB = ((stats3.AvSysNVMEUsed) / 1048576);
        output3.totalSpaceGB = ((stats3.AvSysNVMESize) / 1048576);
        output3.freeSpaceGB = ((output3.totalSpaceGB) - (output3.usedSpaceGB));
		output3.name="NVME-Disk";

        if (output3.totalSpaceGB != 0) {
            output3.utilization = getRoundedToTwoDecimalPlaces(((output3.usedSpaceGB) / (output3.totalSpaceGB)) * 100);
        } else {
            output3.utilization = 0;
        }


        scriptOutput.add(output3);

        print("Completed executing computation script for feature: Flash");
        return true;
    } catch (e) {
        print("failed in DiskName" + "  " + e.stack);
        return false;
    }
}

function getOutputTemplate() {
    var output = {
        "componentId" : "Disk-Partition",
		"metricName" : "ciscoFlashPartitionUtilization",
    };
    return output;
}

function getRoundedToTwoDecimalPlaces(doubleValue) {
    return (new java.lang.Double(java.lang.Math.round(doubleValue * 100)))/(100.0);
}