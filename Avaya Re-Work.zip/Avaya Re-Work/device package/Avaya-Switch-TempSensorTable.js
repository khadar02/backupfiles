getTempSensorTable();

function getTempSensorTable() {

    try {
        print("Executing computation script for feature: TemperatureTable");
        for (var i = 0; i < TemperatureTable.size(); i++) {
            var stats = TemperatureTable.get(i);
            output = getOutputTemplate();
            output.index = String(i)+"";

            output.AvSysTempSensorID = stats.AvSysTempSensorID;
            output.temperatureCelsius = stats.AvSysTempSensorValue;


            output.metricName = "ciscoEnvMonTemperatureState";

            output.componentId = "Sensor";

            output.label = "TempSensor" + "-" + output.AvSysTempSensorID;

            scriptOutput.add(output);
        }
        print("Completed executing computation script for feature: TemperatureTable");
        return true;
    } catch (e) {
        print("failed in TemperatureTable" + "  " + e.stack);
        return false;
    }
}

function getOutputTemplate() {
    var output = {

    };
    return output;
}