getMemory();

function getMemory() {
    try {
        print("Executing computation script for feature: Memory");
        var stats = Memory.get(0);
        output = getOutputTemplate();
        output.AvSysMemSize = stats.AvSysMemSize; // in MB
        output.AvSysMemUsed = stats.AvSysMemUsed;
        output.AvSysMemFree = stats.AvSysMemFree; //in kilobytes	

        output.utilization = getRoundedToTwoDecimalPlaces((stats.AvSysMemUsed) / 1024);


        scriptOutput.add(output);
        print("Completed executing computation script for feature: Memory");
        return true;
    } catch (e) {
        print("failed in Memory" + "  " + e.stack);
        return false;
    }
}

function getRoundedToTwoDecimalPlaces(doubleValue) {
   return (Math.round(doubleValue * 100))/100.0;
}

function getOutputTemplate() {
    var output = {
        "name": "Memory",
        "utilization": 0,
        "component": "device-memory-pool"
    };
    return output;
}