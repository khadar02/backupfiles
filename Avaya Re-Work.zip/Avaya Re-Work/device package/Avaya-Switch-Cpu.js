getCpu();

function getCpu() {

    try {
        print("Executing computation script for feature: Cpu");
        var stats = Cpu.get(0);
        output = getOutputTemplate();

        output.utilization = stats.AvSysCpuUsage;

        scriptOutput.add(output);
        print("Completed executing computation script for feature: Cpu");
        return true;
    } catch (e) {
        print("failed in Cpu" + "  " + e.stack);
        return false;
    }
}

function getOutputTemplate() {
    var output = {
        "name": "CPU",
        "component": "CPU"
    };
    return output;
}