getPowerSupplyTable();

function getPowerSupplyTable() {

    try {
        print("Executing computation script for feature: PowerSupplyTable");
        for (var i = 0; i < PowerSupplyTable.size(); i++) {
            var stats = PowerSupplyTable.get(i);
            output = getOutputTemplate();
            output.index = String(i) + "";
            output.PowerSupplySensorID = stats.PowerSupplySensorID;
            
            output.metricName = "ciscoEnvMonSupplyState";
            output.componentId = "PowerSupply";
            output.label = "PowerSupply" + "-" + stats.PowerSupplySensorID;

            if (stats.PowerSupplyStatus == 3) {
                output.statusValue = 100;
                output.statusString = "normal";
            } else {
                output.statusValue = 0;
                output.statusString = "failed";
            }

            scriptOutput.add(output);
        }
        print("Completed executing computation script for feature: PowerSupplyTable");
        return true;
    } catch (e) {
        print("failed in PowerSupplyTable" + "  " + e.stack);
        return false;
    }
}

function getOutputTemplate() {
    var output = {

    };
    return output;
}