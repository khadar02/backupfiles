getFanSensorTable();

function getFanSensorTable() {

    try {
        print("Executing computation script for feature: FanTable");
        for (var i = 0; i < FanTable.size(); i++) {
            var stats = FanTable.get(i);

            output = getOutputTemplate();
            output.index = String(i) + "";
            output.AvSysFanID = stats.AvSysFanID;
            output.componentId = "Fan";

            output.label ="Fan"+ "-" + output.AvSysFanID;
            if (stats.AvfanStatus == 2) {
                output.statusValue = 100;
                output.statusString = "normal";
            } else {
                output.statusValue = 0;
                output.statusString = "failed";
            }

            output.metricName = "ciscoEnvMonFanState";
            scriptOutput.add(output);
        }
        print("Completed executing computation script for feature: FanTable");
        return true;
    } catch (e) {
        print("failed in FanTable" + "  " + e.stack);
        return false;
    }
}

function getOutputTemplate() {
    var output = {

    };
    return output;
}