getrfu();
function getrfu() {
	try {
		print("Executing computation script for feature: rfu");
		for (var i = 0; i < rfu.size(); i++) {
			var stats = rfu.get(i);
			output1=getOutputTemplate();
			
			output1.index=String(i);
			
			output1.rxlevel=stats.genEquipRfuStatusRxLevel;
			
			
			output1.label="RFU"+" "+i;
			output1.metricName="RxLevel";
			output1.component="Rx Level";
			
			scriptOutput.add(output1);
			
			print("Completed executing computation script for feature: rfu");
			
		}
		return true;
	}
	catch (e) {
			print("failed in rfu" + "  " + e.stack);
			return false;
		}
}

function getOutputTemplate () {
	var output = {
	};
	return output;
}

getremoteRadio();
function getremoteRadio() {
	try {
		print("Executing computation script for feature: device remoteRadio");
		for (var i = 0; i < remoteRadio.size(); i++) {
			var stats = remoteRadio.get(i);
			output2=getOutputTemplate();
			
			output2.index=String(i);
			
			output2.rxlevel=stats.genEquipRemoteRadioRemoteRxLevel;
			
			output2.label="Remote Radio"+" "+i;
			output2.metricName="RxLevel";	
			output2.component="Rx Level";
			
			scriptOutput.add(output2);
			
			print("Completed executing computation script for feature: device remoteRadio");
			
		}
		return true;
	}
	catch (e) {
			print("failed in device remoteRadio" + "  " + e.stack);
			return false;
		}
}