getTemperature();
function getTemperature() {
	try {
		print("Executing computation script for feature: Temperature Script");
		for (var i = 0; i < Temperature.size(); i++) {
			var stats = Temperature.get(i);
			output=getOutputTemplate();
			output.index=String(i)+"";
			
			output.label="Temperature";
			
			output.temperatureCelsius=stats.genEquipUnitIduTemperature;
			output.metricName="ciscoEnvMonTemperatureState";
			scriptOutput.add(output);
			
			print("Completed executing computation script for feature: Temperature Script");
			return true;
		}
	}
	catch (e) {
			print("failed in Radio Status" + "  " + e.stack);
			return false;
		}
}

function getOutputTemplate () {
	var output = {
		"componentId" : "Sensor",
		"metricName" : "ciscoEnvMonTemperatureState"
	};
	return output;
}