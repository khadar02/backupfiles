getrfu();
function getrfu() {
	try {
		print("Executing computation script for feature: rfu");
		for (var i = 0; i < rfu.size(); i++) {
			var stats = rfu.get(i);
			output1=getOutputTemplate();
			
			output1.index=String(i);
			
			/*RFU Communication*/
			
			if (stats.genEquipRfuStatusCommunication==0)
			{
				output1.Communication=0;
				output1.statusString="Down";
			}
			else
			{
				output1.Communication=100;
				output1.statusString="UP";
			}
			
			output1.label="RFU"+" "+i;
			output1.metricName="Communication";	
			
			scriptOutput.add(output1);
			
			print("Completed executing computation script for feature: rfu");
			
		}
		return true;
	}
	catch (e) {
			print("failed in rfu" + "  " + e.stack);
			return false;
		}
}

function getOutputTemplate () {
	var output = {
	};
	return output;
}

getremoteRadio();
function getremoteRadio() {
	try {
		print("Executing computation script for feature: device remoteRadio");
		for (var i = 0; i < remoteRadio.size(); i++) {
			var stats = remoteRadio.get(i);
			output2=getOutputTemplate();
			
			output2.index=String(i);
			
			if (stats.genEquipRemoteRadioRemoteCommunication==0)
			{
				output2.Communication=0;
				output2.statusString="Down";
			}
			else
			{
				output2.Communication=100;
				output2.statusString="UP";
			}
			
			output2.label="Remote Radio"+" "+i;
			output2.metricName="Communication";	
			
			scriptOutput.add(output2);
			
			print("Completed executing computation script for feature: device remoteRadio");
			
		}
		return true;
	}
	catch (e) {
			print("failed in device remoteRadio" + "  " + e.stack);
			return false;
		}
}