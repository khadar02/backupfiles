function cambium_radiomse(data) {
var a= parseFloat(data.RadioMSE);
data.point.addField("type", "Radio MSError");
return new java.lang.Double(a); 
}