function cambium_rxlevel(data) {
data.point.addField("type", data.label);
return new java.lang.Double(data.rxlevel);
}