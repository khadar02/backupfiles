getVoltage();
function getVoltage() {
	try {
		print("Executing computation script for feature: Input Voltage");
		for (var i = 0; i < Voltage.size(); i++) {
			var stats = Voltage.get(i);
			output=getOutputTemplate();
			
			output.Voltage=stats.genEquipUnitIduVoltageInput;
			output.component="Input Voltage";
			
			/*voltageSensorName has to be changed according to your number of voltages. This will be the label*/
			output.voltageSensorName="Input Voltage";
			
			output.metricName="Voltage"
			scriptOutput.add(output);
			
			print("Completed executing computation script for feature: Input Voltage");
			return true;
		}
	}
	catch (e) {
			print("failed in Radio Status" + "  " + e.stack);
			return false;
		}
}

function getOutputTemplate () {
	var output = {
	};
	return output;
}
