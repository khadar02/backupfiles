function cambium_communication(data) {
data.point.addField("type", data.label);
return new java.lang.Double(data.Communication);
}