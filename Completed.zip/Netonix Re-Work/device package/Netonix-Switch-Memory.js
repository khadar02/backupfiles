getMemoryReal();
function getMemoryReal() {
        try {
                print("Executing computation script for feature: MemoryReal");
				
	var stats = MemoryReal.get(0);
                output=getOutputTemplate();
				output.memTotalReal=stats.memTotalReal;
				output.memAvailReal=stats.memAvailReal;

				output.utilization=getRoundedToTwoDecimalPlaces(((output.memTotalReal-output.memAvailReal)/output.memTotalReal)*100);

                scriptOutput.add(output);
				
				print("Completed executing computation script for feature: MemoryReal");
                return true;
            }
         catch (e) {
                print("failed in MemoryReal" + "  " + e.stack);
                return false;
        }
}

function getRoundedToTwoDecimalPlaces(doubleValue) {
   return (new java.lang.Double(java.lang.Math.round(doubleValue * 100)))/(100.0);
}
function getOutputTemplate () {
        var output = {
				"component":"Memory",
				"name":"Memory"
			};
        return output;
}



