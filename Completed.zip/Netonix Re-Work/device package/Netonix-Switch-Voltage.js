getvoltageTable();

function getvoltageTable() {
	try {
		print("Executing computation script for feature: voltageTable");
		for (var i = 0; i < voltageTable.size(); i++) {
			var stats = voltageTable.get(i);
			output = getOutputTemplate();
			output.index = stats.voltageIndex;

			if (stats.voltageSensorName.indexOf("DCDC") != -1) {
				output.voltageSensorName = stats.voltageSensorName;

				output.component = stats.voltageSensorName;
			} else if (stats.voltageSensorName.indexOf("Board") != -1) {
				output.voltageSensorName = stats.voltageSensorName;

				output.component = "Mother-" + stats.voltageSensorName;
			} else {
				output.voltageSensorName = stats.voltageSensorName;

				output.component = stats.voltageSensorName;
			}


			output.Voltage = (stats.voltage / 100);

			output.metricName = "Voltage"

			scriptOutput.add(output);
			print("Completed executing computation script for feature: voltageTable");
		}
		return true;
	} catch (e) {
		print("failed in voltageTable" + "  " + e.stack);
		return false;
	}
}

function getOutputTemplate() {
	var output = {};
	return output;
}