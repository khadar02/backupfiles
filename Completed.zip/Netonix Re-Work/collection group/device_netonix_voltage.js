function device_netonix_voltage(data) {
data.point.addField("type", data.voltageSensorName);
return new java.lang.Double(data.voltage);
}