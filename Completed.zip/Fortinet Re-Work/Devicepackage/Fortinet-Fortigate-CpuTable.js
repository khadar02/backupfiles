getCpuTable();

function getCpuTable() {

        try {
                print("Executing computation script for feature: CpuTable");
				for (var i = 0; i < CPU.size(); i++) {
				var stats = CPU.get(i);
                output=getOutputTemplate();
				output.index=String(i);
				output.utilization=stats.fgProcessorUsage;
				output.name = "CPU";
                scriptOutput.add(output);
				}
				print("Completed executing computation script for feature: CpuTable");
                return true;
            }
         catch (e) {
                print("failed in CpuTable" + "  " + e.stack);
                return false;
        }
}

function getOutputTemplate () {
        var output = {
                    "utilization":0,
					"name":"CPU",
					"index":0
                  };
                  return output;
}