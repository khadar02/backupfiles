getDiskMetrics();

function getDiskMetrics() {

	try {
		print("Executing computation script getDiskMetrics");
		var stats = Disk.get(0);
		output = getOutputTemplate();

		if (stats.fgSysDiskCapacity == 0) {
			output.totalSpaceGB = 0;

			output.usedSpaceGB = 0;

			output.freeSpaceGB = 0;

			output.utilization = 0;

		} else {
			//output.utilization=float(stats.fgSysDiskUsage)/float(stats.fgSysDiskCapacity)*100;

			output.totalSpaceGB = getRoundedToTwoDecimalPlaces((stats.fgSysDiskCapacity) / (1024 * 1024 * 1024));

			output.usedSpaceGB = getRoundedToTwoDecimalPlaces((stats.fgSysDiskUsage) / (1024 * 1024 * 1024));

			output.freeSpaceGB = getRoundedToTwoDecimalPlaces((stats.fgSysDiskCapacity - stats.fgSysDiskUsage) / (1024 * 1024 * 1024));

			output.utilization = getRoundedToTwoDecimalPlaces(((stats.totalSpaceGB - stats.usedSpaceGB) / (stats.totalSpaceGB)) * 100);

		}
		output.name = "Disk";
		scriptOutput.add(output);
		print("Completed executing computation script getDiskMetrics");
		return true;
	} catch (e) {
		print("failed in getDiskMetrics" + "  " + e.stack);
		return false;
	}
}

function getRoundedToTwoDecimalPlaces(doubleValue) {
	return (Math.round(doubleValue * 100)) / 100.0;
}

function getOutputTemplate() {
	var output = {
		"component": "RootDisk",
		"utilization": 0,
		"index": "0",
		"componentId": "Disk-Partition",
		"metricName": "ciscoFlashPartitionUtilization",
	};
	return output;
}
