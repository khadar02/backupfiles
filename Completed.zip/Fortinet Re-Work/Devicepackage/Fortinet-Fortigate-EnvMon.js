getEnvMon();

function getEnvMon() {

        try {
                print("Executing computation script for feature: EnvMon");

				var stats = EnvMon.get(0);
                output=getOutputTemplate();
				output.sysContact=stats.sysContact;
				output.sysLocation=stats.sysLocation;
				output.entPhysicalModelName=stats.entPhysicalModelName;
				output.sysDescr=stats.sysDescr;
				output.SysSerial=stats.fnSysSerial;
				output.sysUpTime=stats.sysUpTime;
				output.fgSysVersion=stats.fgSysVersion;

				output.fgSysVersionIps=stats.fgSysVersionIps;
				output.fgSysVersionAv=stats.fgSysVersionAv;
                                var ts=Date.now()-stats.sysUpTime;
                                var bdate=new Date(ts);
                                output.sysBootTime=bdate.toGMTString();        				scriptOutput.add(output);
				print("Completed executing computation script for feature: EnvMon");
                return true;
            }
         catch (e) {
                print("failed in EnvMon" + "  " + e.stack);
                return false;
        }
}

function getOutputTemplate () {
        var output = {
                    "sysContact" :1,
					"sysLocation" :1,
					"entPhysicalModelName" :1,
					"sysDescr" :1,
					"sysName" :"Fortigate Firewall",
                                        "sysServices":"UTM, Firewall , Routing",
                                        "sysOID":"",
					"sysUpTime" :1
				  };
                  return output;
}
