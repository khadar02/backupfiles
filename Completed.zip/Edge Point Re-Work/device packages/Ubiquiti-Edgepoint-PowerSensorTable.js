getPowerSensorTable();
function getPowerSensorTable() {
	try {
		print("Executing computation script getPowerSensorTable");
		for (var i = 0; i < PowerSensorTable.size(); i++) {
			var stats = PowerSensorTable.get(i);
			var output = getOutputTemplate();
			output.name = "ciscoEnvMonSupplyState";
			output.index=String(i)+"";
			output.boxServicesPowSupplyIndex = stats.boxServicesPowSupplyIndex;
			output.boxServicesPowSupplyItemState = stats.boxServicesPowSupplyItemState;
			
			
			output.label = "PowerSupply" + "-" + i;
			output.name = "ciscoEnvMonSupplyState";
			
			//this is to handle incompatible powersupplies and even not handle the not powering powersupplies also
			if (output.boxServicesPowSupplyItemState == 6 || output.boxServicesPowSupplyItemState == 7) {
				continue;
			}

			if (output.boxServicesPowSupplyItemState == 2 || output.boxServicesPowSupplyItemState == 4) {
				output.statusValue = 100;
				output.StatusString = output.label + " is normal";
			} else {
				output.statusValue = 0;
				output.StatusString = output.label + " failed";
			}
			scriptOutput.add(output);
		}
		print("Completed executing computation script getPowerSensorTable");
		return true;
	} catch (e) {
		print("failed in getPowerSensorTable" + "  " + e.stack)
		return false;
	}
}

function getOutputTemplate() {
	var output = {
		
		"componentId" : "PowerSupply",
		"metricName" : "ciscoEnvMonSupplyState",
		
	};
	return output;
}