getCpu();
	function getCpu() {
		try {
			print("Executing computation script for feature: Cpu");
			var stats = Cpu.get(0);
			var regex = /([0-9|.|]+)/g;
			output=getOutputTemplate();
			var paragraph = stats.agentSwitchCpuProcessTotalUtilization;
			var found = paragraph.match(regex);
			output.utilization=getRoundedToTwoDecimalPlaces(found[5]);
					//output.CpuUtilization=found[5];
			output.name="CPU";
			scriptOutput.add(output);
			print("Completed executing computation script Cpu");
			return true;
		} 
		catch (e) {
			print("failed in Cpu" + "  " + e.stack)
			return false;
		}
	}

function getRoundedToTwoDecimalPlaces(doubleValue) {
   return (Math.round(doubleValue * 100))/100.0;
}

function getOutputTemplate () {
	var output = {
		
	};
	return output;
}

