getTempSensorValueTable();
function getTempSensorValueTable() {
	try {
		print("Executing computation script getTempSensorValueTable");
		for (var i = 0; i < TempSensorValueTable.size(); i++) {
			var stats = TempSensorValueTable.get(i);
			var output = getOutputTemplate();
			
			output.index=String(i)+"";
			output.boxServicesTempSensorIndex = stats.boxServicesTempSensorIndex;
			
			output.temperatureCelsius = stats.boxServicesTempSensorTemperature;
			
			output.TempSensorState=stats.boxServicesTempSensorState;
			
			output.label = "Temperature-sensor-" + i;
			
			
			scriptOutput.add(output);
		}
		print("Completed executing computation script getTempSensorValueTable");
		return true;
	} catch (e) {
		print("failed in getTempSensorValueTable" + "  " + e.stack)
		return false;
	}
}

function getOutputTemplate() {
	var output = {
		
		"componentId" : "Sensor",
		"metricName" : "ciscoEnvMonTemperatureState"
	};
	return output;
}