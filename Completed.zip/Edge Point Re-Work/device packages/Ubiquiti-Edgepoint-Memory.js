getMemory();

function getMemory() {
        try {
			print("Executing computation script for feature: Memory");
				var stats = Memory.get(0);
                output=getOutputTemplate();
				
				output.FreeMemory=stats.agentSwitchCpuProcessMemFree;
				
				output.AvailableMemory=stats.agentSwitchCpuProcessMemAvailable;
				
				output.utilization = (output.FreeMemory/output.AvailableMemory)*100;
				
				output.utilization=getRoundedToTwoDecimalPlaces(output.utilization);
				
				output.name="Memory";
                scriptOutput.add(output);
				print("Completed executing computation script for feature: Memory");
                return true;
		}
		catch(e)
		{
			print("failed in Memory" + "  " + e.stack);
                return false;
		}
}

function getRoundedToTwoDecimalPlaces(doubleValue) {
   return (new java.lang.Double(java.lang.Math.round(doubleValue * 100)))/(100.0);
}

function getOutputTemplate () {
		        var output = {
					
					"name":"Memory"
                  };
				  return output;
}
